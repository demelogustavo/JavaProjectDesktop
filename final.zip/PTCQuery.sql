create database if not exists PTC;
use PTC;

create table if not exists Usuario(
prontuario varchar(8) primary key unique,
email varchar(50),
senha varchar(15),
nome varchar(200),
unique(email),
Visibilidade enum('USUARIO', 'ORIENTADOR', 'ADMINISTRADOR', 'ALUNO'));

create table if not exists Orientador(
idUsuario varchar(7) unique not null,
Constraint fk_idUsuario_orientador foreign key (idUsuario) references Usuario(prontuario) on delete cascade on update cascade,
idOrientador int(5) not null auto_increment,
primary key (idOrientador, idUsuario),
linhaDePesquisa varchar(255),
disciplinas varchar(255));

create table if not exists Tcc(
idTcc int(5) auto_increment,
arquivo longblob default null,
titulo varchar(300),
`data` date,
autores varchar(255),
dataPostagem date default null,
descricao varchar(500) default null,
destaque boolean default false,
nota float(4,2) default 00.00,
numeroPaginas int(255) default 0,
avaliadores varchar(255) default null,
orientador varchar(200),
palavraChaves varchar(200) default null,
-- `status` varchar(50) default null,
tema varchar(200) default null,
curso varchar(100) default null,
unique(data,autores),
primary key(idTcc)
);

create table if not exists Grupo(
idGrupo int(5) unique primary key auto_increment,
nome varchar(30) unique not null,
idWorkflow int (5) default null
);

create table if not exists Aluno(
idUsuario varchar(7) not null,
Constraint fk_idUsuario_aluno foreign key (idUsuario) references Usuario(prontuario) on delete cascade on update cascade,
idAluno int(5) not null auto_increment,
primary key (idAluno, idUsuario),
idGrupo int(5) default null,
Constraint fk_idGrupo foreign key (idGrupo) references Grupo(idGrupo) on delete cascade on update cascade);

create table if not exists Agendamento(
`data` date,
horarioInicio time,
horarioFim time,
descricao varchar(100),	
aceito boolean,
idAgendamento int(5) unique primary key auto_increment,
idGrupo int(5),
constraint fk_Agendamento_Grupo foreign key (idGrupo) references Grupo(idGrupo) on delete cascade on update cascade,
idOrientador int(5),
constraint fk_Agendamento_Orientador foreign key (idOrientador) references Orientador(idOrientador) on update cascade,
unique (`data`, idGrupo, idOrientador));

create table if not exists Workflow(
idWorkflow int(5) primary key auto_increment,
nome varchar(200) unique default null,
descricao varchar(500) default null);

create table if not exists WorkflowGrupo(
idWorkflow int(5)  not null,
idGrupo int(5) primary key not null
);
alter table WorkflowGrupo add constraint FK_WorkflowGrupo_Workflow foreign key (idWorkflow) references Workflow(idWorkflow) on delete cascade on update cascade;
alter table WorkflowGrupo add constraint FK_WorkflowGrupo_Grupo foreign key (idGrupo) references Grupo(idGrupo) on delete cascade on update cascade;

create table if not exists Atividade(
idAtividade int(5) primary key auto_increment,
nome varchar(50) not null,
descricao varchar(100) default null,
obrigatoriedade boolean default false,
idWorkflow int(5),
constraint fk_idWorkflow foreign key (idWorkflow) references Workflow(idWorkflow),
unique(nome,idWorkflow));

create table if not exists AtividadeGrupo(
idAtividade int(5) not null,
finalizada boolean default false,
idGrupo int(5),
constraint fk_atividadegrupo_grupo foreign key (idGrupo) references Grupo(idGrupo) on delete cascade on update cascade,
primary key(idAtividade, idGrupo)
);
alter table AtividadeGrupo add constraint fk_AtividadeGrupo_Atividade foreign key (idAtividade) references Atividade(idAtividade) on delete cascade on update cascade;

create table if not exists FluxoAtividades(
idFluxoAtividades int(5) primary key auto_increment,
idWorkflow int(5),
constraint fk_idWorkflow_FluxoAtividade foreign key (idWorkflow) references Workflow(idWorkflow) on delete cascade on update cascade,
idAtividade int(5) not null,
Constraint fk_idAtividade foreign key (idAtividade) references Atividade(idAtividade) on delete cascade on update cascade,
predecessor int(5) default null,
Constraint fk_idAtividade_predec foreign key (idAtividade) references Atividade(idAtividade) on delete cascade on update cascade,
sequencia int(5) not null,
unique(idWorkflow, idAtividade));

create table if not exists Convite(
idGrupo int(5) not null,
idAluno int(5) not null, 
aceito boolean default false,
Constraint fk_idGrupo_Convite foreign key (idGrupo) references Grupo(idGrupo) on delete cascade on update cascade,
Constraint fk_idAluno_Convite foreign key (idAluno) references Aluno(idAluno) on delete cascade on update cascade,
primary key (idGrupo, idAluno));

alter table Grupo add constraint fk_idWorkflow_gp foreign key (idWorkflow) references Workflow(idWorkflow);
alter table Usuario add column imagem longblob default null;
alter table Usuario add column colors varchar(50) default null;

set GLOBAL max_allowed_packet = 1024*1024*14;
set sql_safe_updates = 0;
update Tcc set `data` = '2015-06-27' where year(`data`) = '207';
set sql_safe_updates = 1;
