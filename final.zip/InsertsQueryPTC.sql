use PTC;

select * from Tcc where titulo like "jdji" or year(`data`) = 2017;

insert into Usuario (prontuario,email,senha ,nome,Visibilidade)
values
('1650103','thegreat@gmail.com', 'richie', 'Ricardo', 'USUARIO'),
('1650105','jujuhipolito@gmail.com', 'jujubs', 'Juliana', 'ADMINISTRADOR'),
('1650106', 'gustavinho17@hotmail.com', 'gogoGustavo', 'Gustavo', 'USUARIO'),
('1650107', 'cacaeufrasino@gmail.com', 'carone', 'Carine', 'ADMINISTRADOR'),
('1650104', 'glaysinho@yahoo.com', 'glaytop', 'Galyson', 'USUARIO'),
('14010', 'lucas@gmail.com', 'lukinha', 'Lucas', 'ORIENTADOR'),
('14587', 'theusinho@hotmail.com', '00000', 'Mathues', 'ORIENTADOR'),
('12354', 'vinicius@vini.com', '4569871', 'Vinicius', 'ORIENTADOR'),
('14577', 'veve@hotmail.com', 'calvissimo', 'Veríssimo','ORIENTADOR'),
('15487', 'thetower@latorre.com', 'latodomin', 'Latorres', 'ORIENTADOR'),
('1450106','fake@gmail.com', 'fakinho', 'Henrique', 'ALUNO'),
('1578960', 'lucaseduardo@gmail.com', 'lukinha', 'Lucas Eduardo', 'ALUNO'),
('1201365', 'kaynito@gmail.com', 'kaynãokaynan', 'Kaynnan', 'ALUNO'),
('1489650', 'lulurocha@gmail.com', 'gabriel', 'Luana', 'ALUNO'),
('1459863', 'tayrone@yahoo.com', 'tayrineee', 'Tayriine', 'ALUNO'),
('1698752', 'bianca@hotmail.com', 'bibi', 'Bianca', 'ALUNO');
-- delete from Usuario where prontuario <> '';
insert into Orientador (idUsuario,linhaDePesquisa, disciplinas)
values
('14010', 'Moda na Usp', 'LETRAS, LPL'),
('14587', 'Android', 'LP1;LG2'),
('12354', 'Sabesp', 'mat, BPS'),
('14577', 'Projetos', 'PJI'),
('15487', 'Programação Java', 'LG2');


insert into Grupo(nome)
values
('Supremacy Corporation'),
('Koalla');

insert into Aluno(idUsuario, idGrupo)
values
('1450106', 1),
('1578960', 1),
('1201365', 1),
('1489650', 2),
('1459863', 2),
('1698752', 2);

insert into Agendamento(`data`,horarioInicio ,horarioFim ,descricao ,aceito,idGrupo,idOrientador)
values
('2017-03-02', '12:00', '13:00', 'Resolver o problema do workflow', false, 1, 5),
('2017-04-02', '12:00', '13:00', 'Resolver o problema da pesquisa', false, 1, 5),
('2017-10-29', '17:00', '17:30', 'Discutir a linha de pesquisa', false, 2, 3);

insert into Workflow(nome, descricao)
values
('Ensino Medio Integrado ao Curso Técnico de Informática', 'Workflow de PDS'),
('Ensino Superior', 'Workflow genérico do ensino superior');

insert into Atividade(nome ,descricao ,obrigatoriedade ,idWorkflow )
values
('Início', 'O começo de tudo', true, 1),
('Meio', 'O meio de tudo', false, 1),
('Fim', 'O fim de tudo', true, 1),
('Início', 'O começo de tudo', true, 2),
('Meio', 'O meio de tudo', false, 2),
('Fim', 'O fim de tudo', true, 2);

insert into WorkflowGrupo(idWorkflow, idGrupo)
values
(1,1),
(1,2);
update Grupo set idWorkflow = 1 where idGrupo = 1;
update Grupo set idWorkflow = 1 where idGrupo = 2;

insert into AtividadeGrupo(idAtividade, idGrupo)
select idAtividade, 1 from Atividade where idWorkflow = 1;
insert into AtividadeGrupo(idAtividade, idGrupo)
select idAtividade, 2 from Atividade where idWorkflow = 1;

insert into FluxoAtividades(idWorkflow,idAtividade, predecessor,sequencia)
values 
(1, 1, null, 0),
(1, 2, 1,1),
(1, 3,2,2),
(2, 1, null, 0),
(2, 2, 1,1),
(2, 3,2,2);


select * from Tcc where nota = 10;
insert into Tcc(arquivo, titulo, `data`, autores, dataPostagem, descricao, destaque, nota, numeroPaginas,
avaliadores, orientador, palavraChaves, tema, curso) 
values (load_file('/home/richie/Downloads/2-claudio1.pdf'), 'A internet das coisas - uma viagem', '2017-10-14', 'Juliana Hipólito, Ricardo Fernando e Carine Eufrasino',
 '2017-10-15','Um tcc top dms; estudo aprofundado sobre IoT', true, '7.5', '150', 'Claudete, Oscar e Veríssimo', 'Luk Cho Man', 
'Top, internet, coisas, tecnologia, IoT', 'Internet das Coisas', 'Técnico em Informática'),
(load_file('/home/richie/Downloads/2-claudio1.pdf'), 'Einstein e as ondas gravitacionais', '2016-11-12', 'Paulete Silva Sales',  '2016-11-15', 
'Estudo sobre ondas', true, '10', '100', 'Crochik, Bonetti, Daniel', 'Cipoli', 
'Física, einstein, ondas', 'Ondas gravitacionais', 'Licenciatura em Física'),
(load_file('/home/richie/Downloads/2-claudio1.pdf'), 'Monografia sobre Machado de Assis','2016-06-14', 'Pedro Campos', '2017-06-15', 
'Estudo dirigido sobre a vida e obras do autor', false, '8.5', '70', 'Alessandra, Fausto, Fabiana', 'Michele', 
'Machado, escritor, monografia', 'Machado de Assis', 'Licenciatura em Letras'),
(load_file('/home/richie/Downloads/2-claudio1.pdf'), 'Portal do TCC','2014-07-13', 'Victor Hugo Girardi, Gabriel Mochi, John Schmitz', '2014-07-15', 
'Tem o intuito de tornar transparentes os TCCs do IFSP', false, '5.5', '120', 'Marcelo, Miyuki, Ricardo', 'Ivan', 
'Portal, web, tcc, armazenamento', 'Portal do Tcc', 'Análise e Desenvolvimento de Sistemas'),
(load_file('/home/richie/Downloads/2-claudio1.pdf'), 'A composição e impacto ambiental da chuva ácida','2015-11-06', 'Jéssica Gomes', '2015-11-12', 
'Estudo sobre as imensas desvantagens da chuva ácida', true, '6.75', '50', 'Cristiane Galle, José Otávio', 'Paulo Gouveia', 
'Chuva ácida, átomos, composição, meio-ambiente', 'Chuva ácida', 'Licenciatura em Química'),
(load_file('/home/richie/Downloads/2-claudio1.pdf'), 'Fractais e suas representações','2016-11-06', 'Lucas da Silva Santos', '2016-11-12', 
'Desenvolvimento teórico e prático no estudo dos fractais', false, '4.75', '40', 'Patrícia Paladino, Lauro Tangerino', 'Gabriela', 
'Fractais, representações, gráficos', 'Fractais', 'Licenciatura em Matemática'),
(load_file('/home/richie/Downloads/2-claudio1.pdf'), 'Tapete do Just Dance','2017-12-05', 'Giovanna Oliveira, Larissa Maciel, Mariana Aparecida', '2017-02-12', 
'Montagem de circuitos eletrônicos do tapete do Just Dance', true, '10', '50', 'Caio, Aline', 'Evandro', 
'Circuitos, circuitos eletrônicos, tapete, eletrônica, componentes', 'Tapete do Just Dance', 'Técnico em Eletrônica');

insert into Tcc(arquivo, titulo, `data`, autores, dataPostagem, descricao, destaque, nota, numeroPaginas,
avaliadores, orientador, palavraChaves, tema, curso) 
values
(null, 'As aventuras de Billy & Mend', '2016-11-15', 'Antonio de Padua; Rosangela Elisabete', '2017-08-08', 'As aventuras de um casal de crianas, que se divertem muito com o Puro Osso',
false, 8, 125, 'Pedro Henrique; Catarina Silva', 'Paulo Coelho', 'desenho; infantil; aventura; fantasia;ficção', 'Cartoon', 'Letras');
use PTC;
INSERT INTO Tcc (idTcc, arquivo, titulo, `data`, autores, dataPostagem, descricao, destaque, nota, numeroPaginas,
avaliadores, orientador, palavraChaves, tema, curso) 
VALUES(0, null, "Stranger Things e a Sociedade Moderna", '2013-08-12', "Cesar Minotti;Fabiano", "2017-11-01", 
 "Uma equipe de paleontólogos encontrou fósseis de umpterossauro de 70 milhões de anos na Mongólia.", true, 10, 112, "Edu Chaves",
 'Derik Silva; Roberto Lopes', "série, stranger things, modernidade, pós-modernidade, sociedade", "Comportamento humano", "Sociologia");
 INSERT INTO Tcc (idTcc, arquivo, titulo, `data`, autores, dataPostagem, descricao, destaque, nota, numeroPaginas,
avaliadores, orientador, palavraChaves, tema, curso) 
VALUES
(0, null, "Meu Deus", '2011-09-11', "Thiago e Periclés", "2016-11-06", 
"De acordo com o que observaram, o animal — antecessor das aves — tinha o tamanho aproximado de um pequeno avião.", false, 7.2, 54, 
"Everton Santos", 'Roberta Carla', "ciência, humanidade, crença, fé", "Comportamento humano", "Filosofia");
INSERT INTO Tcc (idTcc, arquivo, titulo, `data`, autores, dataPostagem, descricao, destaque, nota, numeroPaginas,
avaliadores, orientador, palavraChaves, tema, curso) 
VALUES
(0, null, "Canetas e a Influência Nas Crianças", '2014-01-01', "Juliana Hipolito, Rafaela Julião e Matheus Moreira", "2015-05-31", 
"Sua espécie ainda não foi identificada, mas o tamanho dos ossos cervicais encontrados já mostram o porte do animal.", true, 8.9, 82, 
"Edu Chaves", 'Péricles',"influência, canetas, lápis, escrita, crianças", "Comportamento humano", "Geografia");
INSERT INTO Tcc (idTcc, arquivo, titulo, `data`, autores, dataPostagem, descricao, destaque, nota, numeroPaginas,
avaliadores, orientador, palavraChaves, tema, curso) 
VALUES
(0, null, "Amigos: demônios ou anjos?", '2010-06-25', "Carine Euflausino", "2017-11-02", 
"Eu imediatamente reconheci que poderia ser um pterossauro e fiquei atônito com seu tamanho gigantesco", false, 6.7, 76, 
"Mariana Dias", 'Pedro Henrique',"amigos, relação, amizade, ódio", "Comportamento humano", "Biologia"),
(0, null, "Fóssil de Dinossauro", '2011-09-09', "Ricardo Santos e Cecília Dourado", "2016-11-13", 
"O local é uma formação geológica no deserto de Gobi onde muitos fósseis de dinossauros foram descobertos.", true, 8.8, 149, 
"Bentinho", 'Luzinha', "história, ciência, fóssil, dinossauro", "Palentologia", "Biologia"),
(0, null, "Matemática: inimiga ou arquinimiga?", '2017-08-25', "Lauro Tangerino e Patrícia Paladino", "1978-11-01", 
"Definitivamente está junto com os maiores pterossauros, não há nada como isso na Ásia até agora.", true, 9.5, 178, "Gabriela Cotim",
'Fábio Arruda', "matemática, ciência", "Matemática", "Matemática");
INSERT INTO Tcc (idTcc, arquivo, titulo, `data`, autores, dataPostagem, descricao, destaque, nota, numeroPaginas,
avaliadores, orientador, palavraChaves, tema, curso) 
VALUES
(0, null, "Língua Portuguesa e suas Dialéticas", '2013-08-30', "Fabrício Matias", "2015-05-31", 
"É uma vértebra realmente grande, e a única coisa comparável é um material da Romênia.", true, 8, 62, 
"Aiolanda Pereira", 'Teresa Cristina', "português, língua portuguesa, dialéticas", "Modernidades da Língua Portuguesa", "Letras"),
(0, null, "Eletricidade: atraso ou retrocesso?", '2013-08-30', "Luiza Safra", "2017-11-06", 
"Perereca-Onça: conheça a nova espécie descoberta na Amazônia", false, 5.3, 25, "Claudete Alves", 
'Latodomim', "elétrica, eletronica, eletrotécnica, eletricidade", "Elétrica", "Eletrônica");
INSERT INTO Tcc (idTcc, arquivo, titulo, `data`, autores, dataPostagem, descricao, destaque, nota, numeroPaginas,
avaliadores, orientador, palavraChaves, tema, curso) 
VALUES
(0, null, "Robôs são a Neovolução", '2013-08-30', "Tatiana Maslany e Daphne Rudne", "2017-05-30", 
"Por conta da semelhança, a nova perereca foi batizada de Scinax onca, em referência à Onça Pintada.", false, 6, 48, 
'Cipoli', 'Galle; Zé Otávio', "neociencia, evolução, Darwin", "Neovolução", "Física");
INSERT INTO Tcc (idTcc, arquivo, titulo, `data`, autores, dataPostagem, descricao, destaque, nota, numeroPaginas,
avaliadores, orientador, palavraChaves, tema, curso) 
VALUES
(0, null, "Por que Engenharia de Produção não é considerada engenharia?", '207-11-06', "José Pereira", "2016-05-30", 
"A Perereca-Onça foi descoberta na região sudoeste do estado do Amazonas, na área de Floresta Amazônica localizada entre os rios 
Madeira e Purus, ambos afluentes do Rio Amazonas.", true, 7.9, 103, 'Carine Euflasino', 'Roberto Carlos', 
"engenharia, engenharia de produção", "Engenharia", "Engenharia de Produção"); 